namespace Calculator
{
    public partial class Form1 : Form
    {

        private string current = "";

        private List<int> numbers = new List<int>();
        private List<Operation> operations = new List<Operation>();

        bool finished = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_1_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "1";
            label_Show.Text = current;
        }

        private void btn_2_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "2";
            label_Show.Text = current;
        }

        private void btn_3_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "3";
            label_Show.Text = current;
        }

        private void btn_4_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "4";
            label_Show.Text = current;
        }

        private void btn_5_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "5";
            label_Show.Text = current;
        }

        private void btn_6_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "6";
            label_Show.Text = current;
        }

        private void btn_7_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "7";
            label_Show.Text = current;
        }

        private void btn_8_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "8";
            label_Show.Text = current;
        }

        private void btn_9_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "9";
            label_Show.Text = current;
        }

        private void bnt_0_Click(object sender, EventArgs e)
        {

            if (finished) return;

            current += "0";
            label_Show.Text = current;
        }

        private void btn_plus_Click(object sender, EventArgs e)
        {

            if (finished) return;
            if (CheckEmpty()) return;

            operations.Add(Operation.Plus);
            Save();
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {

            if (finished) return;
            if (CheckEmpty()) return;

            operations.Add(Operation.Minus);
            Save();
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {

            if (finished) return;
            if (CheckEmpty()) return;

            operations.Add(Operation.Divide);
            Save();
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {

            if (finished) return;
            if (CheckEmpty()) return;

            operations.Add(Operation.Multiply);
            Save();
        }

        private bool CheckEmpty()
        {
            return label_Show.Text == "";
        }

        private void Save()
        {
            numbers.Add(int.Parse(label_Show.Text));
            current = "";
            label_Show.Text = "Click the buttons:";
        }

        private double Count()
        {
            double result = 0; 
            int operationIndex;
            Operation operation;

            for (int i = 0; i < numbers.Count; i++)
            {
                operationIndex = i - 1;

                if (operationIndex < 0)
                    operation = Operation.Plus;
                else
                    operation = operations[operationIndex];

                if (operation == Operation.Plus)
                {
                    result += numbers[i];
                } else if (operation == Operation.Minus)
                {
                    result -= numbers[i];
                } else if (operation == Operation.Multiply)
                {
                    result *= numbers[i];
                } else if (operation == Operation.Divide)
                {
                    result /= numbers[i];
                }
            }

            return result;
        }

        private void btn_result_Click(object sender, EventArgs e)
        {
            if (finished) return;
            Save();
            label_Show.Text = Count().ToString();

            finished = true;
        }
    }

    public enum Operation
    {
        Plus,
        Minus,
        Divide,
        Multiply
    }
}